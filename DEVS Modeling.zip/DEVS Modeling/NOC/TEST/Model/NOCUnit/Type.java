package Model.NOCUnit;


public enum Type {
    DATA, COMMAND
}
