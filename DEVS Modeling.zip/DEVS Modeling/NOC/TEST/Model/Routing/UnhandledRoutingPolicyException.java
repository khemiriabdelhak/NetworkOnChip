package Model.Routing;

public class UnhandledRoutingPolicyException extends Throwable {

    public UnhandledRoutingPolicyException(String message) {
        super(message);
    }

}
