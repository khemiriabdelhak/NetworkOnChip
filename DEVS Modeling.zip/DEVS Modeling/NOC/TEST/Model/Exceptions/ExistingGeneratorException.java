package Model.Exceptions;

public class ExistingGeneratorException extends Exception {

        public ExistingGeneratorException(String msg) {
            super(msg);
        }


}
