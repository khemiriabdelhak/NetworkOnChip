package NOCUnit;

import DEVSModel.DEVSCoupled;

public class QueueSwitch extends DEVSCoupled {

	@Override
	public void setSelectPriority() {

	}
}
