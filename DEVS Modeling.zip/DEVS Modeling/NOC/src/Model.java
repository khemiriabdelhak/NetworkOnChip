import org.w3c.dom.Document;

import java.io.File;

public interface Model {

    void save_model(Document doc);
}
