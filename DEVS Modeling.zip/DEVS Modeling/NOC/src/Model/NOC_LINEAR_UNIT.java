package Model;

public class NOC_LINEAR_UNIT extends NOC_Unit {
    public NOC_LINEAR_UNIT(NodeCoordinate coordinate) {
        super(coordinate);
    }
}
